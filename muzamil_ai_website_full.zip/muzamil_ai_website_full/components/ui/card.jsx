export function Card({ children, className = "" }) {
  return <div className={`rounded-xl p-4 bg-gray-800 shadow ${className}`}>{children}</div>;
}
