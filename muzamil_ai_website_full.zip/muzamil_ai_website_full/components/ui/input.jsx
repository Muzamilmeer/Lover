export function Input({ ...props }) {
  return <input {...props} className={`p-2 rounded bg-gray-700 text-white w-full ${props.className}`} />;
}
